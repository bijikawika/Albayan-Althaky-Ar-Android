package com.kawika.smart_survey.utils;
/*
 * Created by akhil on 15/02/18.
 */

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.preference.PreferenceManager;

import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.preferences.AppPreferences;

import java.util.Locale;

public class LocaleManager {

    private static final String LANGUAGE_ENGLISH = "en";
    private static final String LANGUAGE_KEY = "language_key";

    public static Context setLocale(Context c) {
        return updateResources(c, getLanguage(c));
    }

    public static Context setNewLocale(Context c, int language) {
        persistLanguage(c, language);
        return updateResources(c, language);
    }

    public static Integer getLanguage(Context c) {
        AppPreferences appPreferences = AppPreferences.getInstance(c, AppConfiguration.SMART_SURVEY_PREFS);

        return appPreferences.getInt(AppConfiguration.LANGUAGE_ID);
    }

    @SuppressLint("ApplySharedPref")
    private static void persistLanguage(Context c, int language) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(c);
        // use commit() instead of apply(), because sometimes we kill the application process immediately
        // which will prevent apply() to finish
        if (language == 1)
            prefs.edit().putString(LANGUAGE_KEY, "en").commit();
        else
            prefs.edit().putString(LANGUAGE_KEY, "ar").commit();

    }

    private static Context updateResources(Context context, int language) {
        Locale locale;
        if (language == 1) {
            locale = new Locale("en");
        } else {
            locale = new Locale("ar");
        }
        Locale.setDefault(locale);

        Resources res = context.getResources();
        Configuration config = new Configuration(res.getConfiguration());
        if (Build.VERSION.SDK_INT >= 17) {
            config.setLocale(locale);
            context = context.createConfigurationContext(config);
        } else {
            config.locale = locale;
            res.updateConfiguration(config, res.getDisplayMetrics());
        }
        return context;
    }

    public static Locale getLocale(Resources res) {
        Configuration config = res.getConfiguration();
        return Build.VERSION.SDK_INT >= 24 ? config.getLocales().get(0) : config.locale;
    }
}