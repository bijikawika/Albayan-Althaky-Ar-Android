package com.kawika.smart_survey.application;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.support.v7.app.AppCompatDelegate;
import android.util.Log;

import com.kawika.smart_survey.api_services.RetrofitService;
import com.kawika.smart_survey.callbacks.LifeCycleDelegate;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.preferences.AppPreferences;
import com.kawika.smart_survey.services.BackgroundMusicService;
import com.kawika.smart_survey.utils.LocaleManager;

import java.util.Locale;

/*
 * Created by Senthil on 06-02-2017.
 */
public class SmartSurveyApplication extends Application implements LifeCycleDelegate {
    private RetrofitService mRetrofitService;
    private Locale locale = null;

    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        //life cycle
        AppLifecycleHandler lifeCycleHandler = new AppLifecycleHandler(this);
        registerActivityLifecycleCallbacks(lifeCycleHandler);
        registerComponentCallbacks(lifeCycleHandler);
    }


    public static SmartSurveyApplication get(Context context) {
        return (SmartSurveyApplication) context.getApplicationContext();
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LocaleManager.setLocale(this);
    }

    public RetrofitService getRetrofitService() {
        if (mRetrofitService == null) {
            mRetrofitService = RetrofitService.Factory.create();
        }
        return mRetrofitService;
    }

    public void setRetrofitService(RetrofitService mRetrofitService) {
        this.mRetrofitService = mRetrofitService;
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }

    public void onAppBackgrounded() {
        Log.d("Application www", "App in background");
        BackgroundMusicService.StopService(this);
    }

    public void onAppForegrounded() {
        Log.d("Application Yeeey", "App in foreground");
        BackgroundMusicService.StartService(this);
    }

}
