package com.kawika.smart_survey.views;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.kawika.smart_survey.R;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.models.Catalog;
import com.kawika.smart_survey.preferences.AppPreferences;

import java.util.Locale;

public class WelcomeActivity extends BaseAppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_activity);

        Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        final AppPreferences appPreferences = AppPreferences.getInstance(WelcomeActivity.this, AppConfiguration.SMART_SURVEY_PREFS);
        if (appPreferences.getBoolean(AppConfiguration.IS_LANGUAGE_SET)){
            if (appPreferences.getBoolean(AppConfiguration.IS_LOGGED)) {
                startActivity(new Intent(WelcomeActivity.this, HomeActivity.class));
                finish();
            }
            else{
                startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
            }

        }

        Button englishButton = findViewById(R.id.englishButton);
        englishButton.setOnClickListener(view -> {
            System.out.println("view = " + view);
            appPreferences.saveInt(AppConfiguration.LANGUAGE_ID, 1);
            appPreferences.saveData(AppConfiguration.LANGUAGE_NAME, getResources().getString(R.string.english));
            appPreferences.saveBoolean(AppConfiguration.IS_LANGUAGE_SET, true);
            Intent i = new Intent(WelcomeActivity.this, LoginActivity.class);
            i.putExtra(EXTRA_TYPE, TYPE_PROGRAMMATICALLY);
            transitionTo(i);
        });

        Button arabicButton = findViewById(R.id.arabicButton);
        arabicButton.setOnClickListener(view -> {
            appPreferences.saveInt(AppConfiguration.LANGUAGE_ID, 2);
            appPreferences.saveData(AppConfiguration.LANGUAGE_NAME, getResources().getString(R.string.arabic));
            appPreferences.saveBoolean(AppConfiguration.IS_LANGUAGE_SET, true);
            startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
        });

    }


}
