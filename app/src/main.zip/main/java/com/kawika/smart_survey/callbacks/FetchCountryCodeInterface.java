package com.kawika.smart_survey.callbacks;

/**
 * Created by senthiljs on 19/01/18.
 */

public interface FetchCountryCodeInterface {
    public void coursesFetchingCompleted(boolean b);
}