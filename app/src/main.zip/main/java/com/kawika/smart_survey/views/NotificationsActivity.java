package com.kawika.smart_survey.views;

import android.databinding.DataBindingUtil;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

import com.kawika.smart_survey.R;
import com.kawika.smart_survey.databinding.HomeActivityBinding;
import com.kawika.smart_survey.databinding.MyScoreActivityBinding;
import com.kawika.smart_survey.databinding.NotificationActivityBinding;

import static com.kawika.smart_survey.utils.SupportClass.BOTTOM_RIGHT;
import static com.kawika.smart_survey.utils.SupportClass.CENTER;
import static com.kawika.smart_survey.utils.SupportClass.showWithCircularRevealAnimation;

/**
 * Created by senthiljs on 09/02/18.
 */

public class NotificationsActivity extends BaseActivity {

    NotificationActivityBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                binding.vRevealEffect.post(() -> showWithCircularRevealAnimation(binding.vRevealEffect, CENTER, BOTTOM_RIGHT, NotificationsActivity.this.getResources().getInteger(R.integer.anim_duration_medium)));
            }
        } catch (Exception e) {
            Log.e("Welcome activity", "PermissionM: ", e);
        }

    }

    @Override
    int getContentViewId() {
        return R.layout.notification_activity;
    }

    @Override
    int getNavigationMenuItemId() {
        return R.id.menu_notifications;
    }

    @Override
    NotificationActivityBinding getNotificationBinding() {
        return binding = DataBindingUtil.setContentView(this, R.layout.notification_activity);
    }

    @Override
    MyScoreActivityBinding getMyScoreActivityBinding() {
        return null;

    }
    @Override
    HomeActivityBinding getHomeBinding() {
        return null;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        try{
            System.runFinalization();
            Runtime.getRuntime().gc();
            System.gc();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}