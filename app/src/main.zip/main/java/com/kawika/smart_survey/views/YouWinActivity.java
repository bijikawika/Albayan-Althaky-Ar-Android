package com.kawika.smart_survey.views;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.jinatonic.confetti.CommonConfetti;
import com.kawika.smart_survey.R;
import com.kawika.smart_survey.alerts.AlertDialogCustom;
import com.kawika.smart_survey.api_services.RetrofitService;
import com.kawika.smart_survey.application.SmartSurveyApplication;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.database.CategoriesTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries;
import com.kawika.smart_survey.database.UserDataTableQueries;
import com.kawika.smart_survey.models.CategoriesSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingAnswersSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingMainSqliteModel;
import com.kawika.smart_survey.models.GetQuestionsModel;
import com.kawika.smart_survey.preferences.AppPreferences;
import com.kawika.smart_survey.utils.CustomProgress;
import com.kawika.smart_survey.utils.LocaleManager;
import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.kawika.smart_survey.config.AppConfiguration.BEGINNER_TYPE;
import static com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries.currentlyPlayingAnswersTableQueries;
import static com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries.currentlyPlayingMainTableQueries;

/*
 * Created by senthiljs on 12/02/18.
 */

public class YouWinActivity extends AppCompatActivity implements View.OnClickListener {
    private ViewGroup container;
    private int selectedCategoryId, currentLevelId, stepIdToPlay, totalMark, playerType;
    private ImageView profileImageView;
    private TextView userNameTextView, currentLevelTextView, scoreTextView;
    private Button nextLevelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.win_result_activity);

        container = findViewById(R.id.container);
        findViewById(R.id.viewResultButton).setOnClickListener(this);
        profileImageView = findViewById(R.id.profileImageView);
        userNameTextView = findViewById(R.id.userNameTextView);
        currentLevelTextView = findViewById(R.id.currentLevelTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        nextLevelButton = findViewById(R.id.nextLevelButton);

        nextLevelButton.setOnClickListener(this);

        //winner layout animation handler
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                viewAnimation();
            }
        }, 100);

        Intent myIntent = getIntent();
        Bundle extras = myIntent.getExtras();
        if (extras == null) {
            //without data activity is closing
            finish();
            return;
        }
        selectedCategoryId = myIntent.getIntExtra("selectedCategoryId", 0);
        currentLevelId = myIntent.getIntExtra("currentLevelId", 0);
        stepIdToPlay = myIntent.getIntExtra("stepIdToPlay", 0);
        totalMark = myIntent.getIntExtra("totalMark", 0);
        playerType = myIntent.getIntExtra("playerType", 0);

        setData();
    }

    private void setData() {
        UserDataTableQueries userDataTableQueries = UserDataTableQueries.sharedInstance(YouWinActivity.this);
        userNameTextView.setText(userDataTableQueries.getName());
        if (userDataTableQueries.getProfileImagePath() != null) {
            Picasso.with(YouWinActivity.this)
                    .load(userDataTableQueries.getProfileImagePath())
                    .placeholder(R.drawable.avatar)
                    .error(R.drawable.avatar)
                    .into(profileImageView);
        }

        CategoriesTableQueries followedTopicsTableQueries = CategoriesTableQueries.sharedInstance(YouWinActivity.this);
        CategoriesSqliteModel courseDetailList = followedTopicsTableQueries.getSelectedCategoryBasedById(selectedCategoryId);
        if (courseDetailList != null) {
            ImageView selectedCategoryImageView = findViewById(R.id.selectedCategoryImageView);
            TextView selectedCategoryTextView = findViewById(R.id.selectedCategoryTextView);
            Picasso.with(YouWinActivity.this)
                    .load(courseDetailList.getImage_path())
                    .placeholder(R.drawable.no_resource)
                    .error(R.drawable.no_resource)
                    .into(selectedCategoryImageView);

            selectedCategoryTextView.setText(courseDetailList.getCategory_name());
        }

        currentLevelTextView.setText(String.valueOf(currentLevelId));
        scoreTextView.setText(String.valueOf(totalMark));
    }

    private void viewAnimation() {
        Resources res = getResources();
        int goldDark = res.getColor(R.color.main_pink);
        int goldMed = res.getColor(R.color.yellow);
        int gold = res.getColor(R.color.white);
        int goldLight = res.getColor(R.color.gold_light);
        CommonConfetti.rainingConfetti(container, new int[]{goldDark, goldMed, gold, goldLight})
                .infinite();
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.viewResultButton) {
        }
        if (view.getId() == R.id.nextLevelButton) {
            if (stepIdToPlay == -1) {
                Intent quiz_start_intent = new Intent(YouWinActivity.this, QuizTypeSelectActivity.class);
                quiz_start_intent.putExtra("selectedCategoryId", selectedCategoryId);
                startActivity(quiz_start_intent);
            } else {
                Intent quiz_start_intent = new Intent(YouWinActivity.this, QuizStartActivity.class);
                quiz_start_intent.putExtra("selectedCategoryId", selectedCategoryId);
                quiz_start_intent.putExtra("playerType", playerType);
                quiz_start_intent.putExtra("stepIdToPlay", stepIdToPlay);
                startActivity(quiz_start_intent);
            }
            finish();
        }
    }

    //language wrapper
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }
}