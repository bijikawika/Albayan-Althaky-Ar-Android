package com.kawika.smart_survey.views;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.kawika.smart_survey.R;
import com.kawika.smart_survey.alerts.AlertDialogCustom;
import com.kawika.smart_survey.api_services.RetrofitService;
import com.kawika.smart_survey.application.SmartSurveyApplication;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.database.CategoriesTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries;
import com.kawika.smart_survey.database.UserDataTableQueries;
import com.kawika.smart_survey.models.CategoriesSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingAnswersSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingMainSqliteModel;
import com.kawika.smart_survey.models.GetQuestionsModel;
import com.kawika.smart_survey.models.PlayedLevelsModel;
import com.kawika.smart_survey.preferences.AppPreferences;
import com.kawika.smart_survey.utils.CustomProgress;
import com.kawika.smart_survey.utils.LocaleManager;
import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.kawika.smart_survey.config.AppConfiguration.BEGINNER_TYPE;
import static com.kawika.smart_survey.config.AppConfiguration.EXPERT_TYPE;
import static com.kawika.smart_survey.config.AppConfiguration.INTERMEDIATE_TYPE;
import static com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries.currentlyPlayingAnswersTableQueries;
import static com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries.currentlyPlayingMainTableQueries;

/*
 * Created by senthiljs on 12/02/18.
 */

public class YouLoseActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView selectedCategoryTextView, currentLevelTextView, userNameTextView, typeTextView,
            scoreTextView;
    private ImageView profileImageView;
    private int selectedCategoryId, currentLevelId, stepIdToPlay, totalMark, playerType;
    private Button nextLevelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lose_result_activity);

        Intent myIntent = getIntent();
        Bundle extras = myIntent.getExtras();
        if (extras == null) {
            //without data activity is closing
            finish();
            return;
        }
        selectedCategoryId = myIntent.getIntExtra("selectedCategoryId", 0);
        currentLevelId = myIntent.getIntExtra("currentLevelId", 0);
        stepIdToPlay = myIntent.getIntExtra("stepIdToPlay", 0);
        totalMark = myIntent.getIntExtra("totalMark", 0);
        playerType = myIntent.getIntExtra("playerType", 0);

        System.out.println("totalMark = " + totalMark);

        selectedCategoryTextView = findViewById(R.id.selectedCategoryTextView);
        currentLevelTextView = findViewById(R.id.currentLevelTextView);
        profileImageView = findViewById(R.id.profileImageView);
        userNameTextView = findViewById(R.id.userNameTextView);
        typeTextView = findViewById(R.id.typeTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        nextLevelButton = findViewById(R.id.nextLevelButton);

        nextLevelButton.setOnClickListener(this);

        setData();
    }

    private void setData() {
        CategoriesTableQueries followedTopicsTableQueries = CategoriesTableQueries.sharedInstance(YouLoseActivity.this);
        CategoriesSqliteModel courseDetailList = followedTopicsTableQueries.getSelectedCategoryBasedById(selectedCategoryId);
        if (courseDetailList != null) {
            selectedCategoryTextView.setText(courseDetailList.getCategory_name());
        }

        scoreTextView.setText(String.valueOf(totalMark));

        UserDataTableQueries userDataTableQueries = UserDataTableQueries.sharedInstance(YouLoseActivity.this);
        userNameTextView.setText(userDataTableQueries.getName());
        if (userDataTableQueries.getProfileImagePath() != null) {
            Picasso.with(YouLoseActivity.this)
                    .load(userDataTableQueries.getProfileImagePath())
                    .placeholder(R.drawable.avatar)
                    .error(R.drawable.avatar)
                    .into(profileImageView);
        }

        if (playerType == 1) {
            typeTextView.setText("Beginner");
        } else if (playerType == 2) {
            typeTextView.setText("Intermediate");
        } else if (playerType == 3) {
            typeTextView.setText("Expert");
        }

        currentLevelTextView.setText(String.valueOf(currentLevelId));

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.nextLevelButton) {
            if (stepIdToPlay == -1) {
                Intent quiz_start_intent = new Intent(YouLoseActivity.this, QuizTypeSelectActivity.class);
                quiz_start_intent.putExtra("selectedCategoryId",selectedCategoryId);
                startActivity(quiz_start_intent);
            } else {
                Intent quiz_start_intent = new Intent(YouLoseActivity.this, QuizStartActivity.class);
                quiz_start_intent.putExtra("selectedCategoryId", selectedCategoryId);
                quiz_start_intent.putExtra("playerType", playerType);
                quiz_start_intent.putExtra("stepIdToPlay", stepIdToPlay);
                startActivity(quiz_start_intent);
            }
            finish();
        }
    }

    //language wrapper
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }

}