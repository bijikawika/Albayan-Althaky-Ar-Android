package com.kawika.smart_survey.callbacks;

import com.kawika.smart_survey.models.CategoriesSqliteModel;

import java.util.List;

/**
 * Created by senthiljs on 19/01/18.
 */

public interface FetchCoursesInterface {
    public void coursesFetchingCompleted();
}