package com.kawika.smart_survey.models;

/**
 * Created by Lincoln on 15/01/16.
 */
public class QuestionCountModel {
    private String quesCount;
    private int highlight;


    public String getQuesCount() {
        return quesCount;
    }

    public void setQuesCount(String quesCount) {
        this.quesCount = quesCount;
    }

    public int getHighlight() {
        return highlight;
    }

    public void setHighlight(int highlight) {
        this.highlight = highlight;
    }


}
