package com.kawika.smart_survey.models;

import java.util.List;

/**
 * Created by senthiljs on 09/03/18.
 */

public class TopPlayersModel {

    /**
     * status : 6000
     * message : Top player lists...!!
     * data : [{"firstname":"sen","lastname":"js","user_id":185,"total_mark":30,"user_result_id":61,"image":"a84c9843a303c296998756e33183c108_1520512214.png","category_name":"Financial Regulations and Regulations of the Financial Regulations","rank":1,"image_path":"http://e-learning.kawikatech.com/data/profile/a84c9843a303c296998756e33183c108_1520512214.png"},{"firstname":"Vimal","lastname":"Das","user_id":194,"total_mark":15,"user_result_id":63,"image":"f187ddab966dbf000e61f6898ecd6d57_1520490742.png","category_name":"Financial Regulations and Regulations of the Financial Regulations","rank":2,"image_path":"http://e-learning.kawikatech.com/data/profile/f187ddab966dbf000e61f6898ecd6d57_1520490742.png"}]
     */

    private int status;
    private String message;
    private List<DataBean> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * firstname : sen
         * lastname : js
         * user_id : 185
         * total_mark : 30
         * user_result_id : 61
         * image : a84c9843a303c296998756e33183c108_1520512214.png
         * category_name : Financial Regulations and Regulations of the Financial Regulations
         * rank : 1
         * image_path : http://e-learning.kawikatech.com/data/profile/a84c9843a303c296998756e33183c108_1520512214.png
         */

        private String firstname;
        private String lastname;
        private int user_id;
        private int total_mark;
        private int user_result_id;
        private String image;
        private String category_name;
        private int rank;
        private String image_path;

        public String getFirstname() {
            return firstname;
        }

        public void setFirstname(String firstname) {
            this.firstname = firstname;
        }

        public String getLastname() {
            return lastname;
        }

        public void setLastname(String lastname) {
            this.lastname = lastname;
        }

        public int getUser_id() {
            return user_id;
        }

        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }

        public int getTotal_mark() {
            return total_mark;
        }

        public void setTotal_mark(int total_mark) {
            this.total_mark = total_mark;
        }

        public int getUser_result_id() {
            return user_result_id;
        }

        public void setUser_result_id(int user_result_id) {
            this.user_result_id = user_result_id;
        }

        public String getImage() {
            return image;
        }

        public void setImage(String image) {
            this.image = image;
        }

        public String getCategory_name() {
            return category_name;
        }

        public void setCategory_name(String category_name) {
            this.category_name = category_name;
        }

        public int getRank() {
            return rank;
        }

        public void setRank(int rank) {
            this.rank = rank;
        }

        public String getImage_path() {
            return image_path;
        }

        public void setImage_path(String image_path) {
            this.image_path = image_path;
        }
    }
}
