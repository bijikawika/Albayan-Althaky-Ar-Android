package com.kawika.smart_survey.adapters;
/*
 * Created by akhil on 21/02/18.
 */

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.kawika.smart_survey.R;
import com.kawika.smart_survey.database.TopPlayersTableQueries;
import com.kawika.smart_survey.models.CategoriesSqliteModel;
import com.kawika.smart_survey.models.TopPlayersModel;
import com.kawika.smart_survey.models.TopPlayersSqliteModel;
import com.kawika.smart_survey.views.HomeActivity;
import com.squareup.picasso.Picasso;

import java.util.List;

public class TopPlayersAdapter extends RecyclerView.Adapter<TopPlayersAdapter.RecyclerViewHolders> {


    private Context mContext;
    private List<TopPlayersSqliteModel> topPlayerList;
    private int selectedCategoryId;

    //constructor
    public TopPlayersAdapter(Context context, List<TopPlayersSqliteModel> topPlayerList, int selectedCategoryId) {
        this.mContext = context;
        this.topPlayerList = topPlayerList;
        this.selectedCategoryId = selectedCategoryId;
    }

    public TopPlayersAdapter(Context context, int selectedCategoryId) {
        this.mContext = context;
        this.selectedCategoryId = selectedCategoryId;
    }

    @Override
    public RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = View.inflate(mContext, R.layout.top_players_row_item, null);
        return new RecyclerViewHolders(layoutView);
    }

    @Override
    public void onBindViewHolder(final RecyclerViewHolders holder, final int position) {
        holder.playerNameTextView.setText(topPlayerList.get(position).getFirstname()+" "+ topPlayerList.get(position).getLastname());
        holder.rankBadgeTextView.setText("Rank "+String.valueOf(topPlayerList.get(position).getRank()));
        holder.departmentTextView.setText(topPlayerList.get(position).getCategory_name());
        Picasso.with(mContext)
                .load(topPlayerList.get(position).getImage())
                .placeholder(R.drawable.no_resource)
                .error(R.drawable.no_resource)
                .into(holder.topPlayersImageView);
    }

    @Override
    public int getItemCount() {
        return topPlayerList.size();
    }

    class RecyclerViewHolders extends RecyclerView.ViewHolder {
        TextView playerNameTextView, rankBadgeTextView, departmentTextView;
        ImageView topPlayersImageView;

        RecyclerViewHolders(View itemView) {
            super(itemView);
            playerNameTextView = itemView.findViewById(R.id.playerNameTextView);
            rankBadgeTextView = itemView.findViewById(R.id.rankBadgeTextView);
            departmentTextView = itemView.findViewById(R.id.departmentTextView);
            topPlayersImageView = itemView.findViewById(R.id.topPlayersImageView);

        }
    }
    public void notifyList(List<TopPlayersSqliteModel> topPlayerListUpdate, int updateCategoryId) {
        if (selectedCategoryId == updateCategoryId) {
            this.topPlayerList = topPlayerListUpdate;
            System.out.println("topPlayerList = " + topPlayerList);
            notifyDataSetChanged();
        }
    }
}