package com.kawika.smart_survey.callbacks;

/*
 * Created by akhil on 06/02/18.
 */

public interface RecyclerClick {
    void onRowClick(int position, int count);
}
