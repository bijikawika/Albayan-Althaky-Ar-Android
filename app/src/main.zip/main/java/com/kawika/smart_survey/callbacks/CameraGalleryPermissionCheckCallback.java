package com.kawika.smart_survey.callbacks;

import android.support.v4.app.Fragment;

/**
 * Created by florentchampigny on 02/03/2017.
 */

public interface CameraGalleryPermissionCheckCallback {
    void permissionEnabled();
}
