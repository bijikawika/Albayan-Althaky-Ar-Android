package com.kawika.smart_survey.alerts;

import android.content.Context;
import android.media.MediaPlayer;

import com.kawika.smart_survey.R;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.preferences.AppPreferences;

/**
 * Created by senthiljs on 08/03/18.
 */

public class PlaySound {

    public static void buttonClickSound(Context context) {

        AppPreferences appPreferences = AppPreferences.getInstance(context, AppConfiguration.SMART_SURVEY_PREFS);
        if (appPreferences.getBoolean(AppConfiguration.IS_SOUND_EFFECTS_SET)) {
            MediaPlayer mediaPlayer = MediaPlayer.create(context, R.raw.button_click_sound);

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mediaPlayer) {
                    System.out.println("releaseevesfd");
                    mediaPlayer.release();
                }
            });

        }

    }

}
