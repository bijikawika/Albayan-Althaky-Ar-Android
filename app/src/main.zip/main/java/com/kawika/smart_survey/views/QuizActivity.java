package com.kawika.smart_survey.views;

import android.animation.Animator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearSnapHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.gson.Gson;
import com.kawika.smart_survey.R;
import com.kawika.smart_survey.adapters.QuestionsCountAdapter;
import com.kawika.smart_survey.alerts.AlertDialogCustom;
import com.kawika.smart_survey.api_services.RetrofitService;
import com.kawika.smart_survey.application.SmartSurveyApplication;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.database.CheckedResultsTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries;
import com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries;
import com.kawika.smart_survey.database.ScoresTableQueries;
import com.kawika.smart_survey.database.UserDataTableQueries;
import com.kawika.smart_survey.models.CheckedResultsSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingAnswersSqliteModel;
import com.kawika.smart_survey.models.CurrentlyPlayingMainSqliteModel;
import com.kawika.smart_survey.models.QuestionCountModel;
import com.kawika.smart_survey.models.ScoresSqliteModel;
import com.kawika.smart_survey.models.SubmitResultModel;
import com.kawika.smart_survey.models.SubmitResultsModel;
import com.kawika.smart_survey.preferences.AppPreferences;
import com.kawika.smart_survey.recycler_scroll_control.MyCustomLayoutManager;
import com.kawika.smart_survey.utils.CustomProgress;
import com.kawika.smart_survey.utils.LocaleManager;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.kawika.smart_survey.database.CheckedResultsTableQueries.checkedResultsTableQueries;
import static com.kawika.smart_survey.database.CurrentlyPlayingAnswersTableQueries.currentlyPlayingAnswersTableQueries;
import static com.kawika.smart_survey.database.CurrentlyPlayingMainTableQueries.currentlyPlayingMainTableQueries;
import static com.kawika.smart_survey.database.ScoresTableQueries.scoresTableQueries;

/*
 * Created by senthiljs on 09/02/18.
 */

public class QuizActivity extends AppCompatActivity {
    private List<QuestionCountModel> questionCountModelList = new ArrayList<>();
    private RecyclerView questionCountRecyclerView;
    private QuestionsCountAdapter mAdapter;
    private int positionCount = -1, totalScore = 0;
    private View optionOneView, optionTwoView, optionThreeView;
    private TextView optionOneTextView, optionTwoTextView, optionThreeTextView, questionTextView, counterTextView, userNameTextView, myScoreTextView;
    private RelativeLayout validOneRelativeLayout, validTwoRelativeLayout, validThreeRelativeLayout,
            invalidOneRelativeLayout, invalidTwoRelativeLayout, invalidThreeRelativeLayout;
    private FrameLayout optionOneMainFrameLayout, optionTwoMainFrameLayout, optionThreeMainFrameLayout;
    private int delayDuration = 300;
    private int fadeInDuration = 700;
    private CountDownTimer count;
    private boolean isCountDownFinish = false;
    private ImageView profileImageView;
    private List<CurrentlyPlayingAnswersSqliteModel> currentlyPlayingAnswersSqliteModelArrayList;
    private ArrayList<CurrentlyPlayingMainSqliteModel> currentlyPlayingMainSqliteModel;
    private boolean isClickEnabled = true;
    private int answerSelectId;
    private String passed_result = "";
    private int fullyScored = 1;
    private AppPreferences appPreferences;
    private int stepIdToPlay = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_activity);

        currentlyPlayingMainTableQueries = CurrentlyPlayingMainTableQueries.sharedInstance(QuizActivity.this);
        currentlyPlayingAnswersTableQueries = CurrentlyPlayingAnswersTableQueries.sharedInstance(QuizActivity.this);
        checkedResultsTableQueries = CheckedResultsTableQueries.sharedInstance(getApplicationContext());
        scoresTableQueries = ScoresTableQueries.sharedInstance(getApplicationContext());

        appPreferences = AppPreferences.getInstance(QuizActivity.this, AppConfiguration.SMART_SURVEY_PREFS);

        userNameTextView = findViewById(R.id.userNameTextView);
        profileImageView = findViewById(R.id.profileImageView);
        optionOneView = findViewById(R.id.optionOneView);
        optionTwoView = findViewById(R.id.optionTwoView);
        optionThreeView = findViewById(R.id.optionThreeView);
        optionOneTextView = findViewById(R.id.optionOneTextView);
        optionTwoTextView = findViewById(R.id.optionTwoTextView);
        optionThreeTextView = findViewById(R.id.optionThreeTextView);
        validOneRelativeLayout = findViewById(R.id.validOneRelativeLayout);
        validTwoRelativeLayout = findViewById(R.id.validTwoRelativeLayout);
        validThreeRelativeLayout = findViewById(R.id.validThreeRelativeLayout);

        invalidOneRelativeLayout = findViewById(R.id.invalidOneRelativeLayout);
        invalidTwoRelativeLayout = findViewById(R.id.invalidTwoRelativeLayout);
        invalidThreeRelativeLayout = findViewById(R.id.invalidThreeRelativeLayout);

        optionOneMainFrameLayout = findViewById(R.id.optionOneMainFrameLayout);
        optionTwoMainFrameLayout = findViewById(R.id.optionTwoMainFrameLayout);
        optionThreeMainFrameLayout = findViewById(R.id.optionThreeMainFrameLayout);
        questionTextView = findViewById(R.id.questionTextView);
        myScoreTextView = findViewById(R.id.myScoreTextView);

        UserDataTableQueries userDataTableQueries = UserDataTableQueries.sharedInstance(QuizActivity.this);
        userNameTextView.setText(userDataTableQueries.getName());
        myScoreTextView.setText(userDataTableQueries.getMyScore());
        if (userDataTableQueries.getProfileImagePath() != null) {
            Picasso.with(QuizActivity.this)
                    .load(userDataTableQueries.getProfileImagePath())
                    .placeholder(R.drawable.avatar)
                    .error(R.drawable.avatar)
                    .into(profileImageView);
        }
        currentlyPlayingMainSqliteModel = currentlyPlayingMainTableQueries.getAllMainQuestions();

        scrollCountRcycler();

        resetViews();

        setData();

        findViewById(R.id.quizCloseImageView).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void setData() {
        if (currentlyPlayingMainSqliteModel != null && currentlyPlayingMainSqliteModel.size() > 0) {
            questionTextView.setText(currentlyPlayingMainSqliteModel.get(positionCount).getQuestion());
        }
        currentlyPlayingAnswersSqliteModelArrayList = currentlyPlayingAnswersTableQueries.getSelectedAnswerBasedById
                (currentlyPlayingMainSqliteModel.get(positionCount).getQuestion_id());

        if (currentlyPlayingAnswersSqliteModelArrayList.get(0).getAnswer() != null) {
            optionOneTextView.setText(currentlyPlayingAnswersSqliteModelArrayList.get(0).getAnswer());
        }
        if (currentlyPlayingAnswersSqliteModelArrayList.get(1).getAnswer() != null) {
            optionTwoTextView.setText(currentlyPlayingAnswersSqliteModelArrayList.get(1).getAnswer());
        }
        if (currentlyPlayingAnswersSqliteModelArrayList.get(2).getAnswer() != null) {
            optionThreeTextView.setText(currentlyPlayingAnswersSqliteModelArrayList.get(2).getAnswer());
        }


    }

    //dialog for invalid selection
    private void showDialogForInvalidAnswer(String explanation) {
        final Dialog dialog = new Dialog(QuizActivity.this, R.style.DialogTheme);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.invalid_selection_dialog);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogTheme;
        dialog.setCanceledOnTouchOutside(true);

        TextView dialogAnswerExplanationTextView = dialog.findViewById(R.id.dialogAnswerExplanationTextView);
        dialogAnswerExplanationTextView.setText(explanation);

        dialog.setOnCancelListener(dialogInterface -> {
            passed_result = "false";
            System.out.println("passed_result = " + passed_result);
            validateResult();
        });
        ImageView cancelPopupImageView = dialog.findViewById(R.id.cancelPopupImageView);
        cancelPopupImageView.setOnClickListener(view -> {
            dialog.cancel();
        });

        dialog.show();
    }

    private void resetViews() {

        positionCount++;

        //clear all views background
        resetViewBackground();

        //set question count
        TextView questionNumberTextView = findViewById(R.id.questionNumberTextView);
        questionNumberTextView.setText(String.valueOf(positionCount + 1));

        //set values
        setData();

        //scroll recycler to position
        questionCountRecyclerView.smoothScrollToPosition(positionCount);
        System.out.println("positionCount = " + positionCount);
        mAdapter.updateRecyclerView(positionCount, questionCountModelList);

        //setting click listeners
        setClickListeners();

        //dropdown animation
        showDropDownAnimation();

        //runCountdown
        startCountdown();
    }

    private void setClickListeners() {
        optionOneTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClickEnabled) {
                    answerSelectId = 0;
                    clickedOption(optionOneView, validOneRelativeLayout, invalidOneRelativeLayout, optionOneTextView);
                }
            }
        });

        optionTwoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClickEnabled) {
                    answerSelectId = 1;
                    clickedOption(optionTwoView, validTwoRelativeLayout, invalidTwoRelativeLayout, optionTwoTextView);
                }
            }
        });
        optionThreeTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isClickEnabled) {
                    answerSelectId = 2;
                    clickedOption(optionThreeView, validThreeRelativeLayout, invalidThreeRelativeLayout, optionThreeTextView);
                }
            }
        });

    }

    private void showDropDownAnimation() {
        optionOneMainFrameLayout.setVisibility(View.INVISIBLE);
        optionTwoMainFrameLayout.setVisibility(View.INVISIBLE);
        optionThreeMainFrameLayout.setVisibility(View.INVISIBLE);
        questionTextView.setVisibility(View.INVISIBLE);

        Handler handler = new Handler();
        handler.postDelayed(() -> {
            questionTextView.setVisibility(View.VISIBLE);
            YoYo.with(Techniques.FadeIn)
                    .duration(fadeInDuration)
                    .playOn(questionTextView);
            Handler handler1 = new Handler();
            handler1.postDelayed(new Runnable() {
                @Override
                public void run() {
                    optionOneMainFrameLayout.setVisibility(View.VISIBLE);
                    YoYo.with(Techniques.FadeInDown)
                            .duration(fadeInDuration)
                            .playOn(optionOneMainFrameLayout);
                    Handler handler1 = new Handler();
                    handler1.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            optionTwoMainFrameLayout.setVisibility(View.VISIBLE);
                            YoYo.with(Techniques.FadeInDown)
                                    .duration(fadeInDuration)
                                    .playOn(optionTwoMainFrameLayout);
                            Handler handler1 = new Handler();
                            handler1.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    optionThreeMainFrameLayout.setVisibility(View.VISIBLE);
                                    YoYo.with(Techniques.FadeInDown)
                                            .duration(fadeInDuration)
                                            .playOn(optionThreeMainFrameLayout);

                                }
                            }, delayDuration);
                        }
                    }, delayDuration);
                }
            }, 400);
        }, 0);
    }

    private void clickedOption(View optionView, RelativeLayout validRelativeLayout, RelativeLayout invalidRelativeLayout,
                               TextView optionTextView) {
        isClickEnabled = false;
        count.cancel();
        YoYo.with(Techniques.FadeIn)
                .duration(400)
                .repeat(5)
                .withListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animator) {

                    }

                    @Override
                    public void onAnimationEnd(Animator animator) {
                        if (currentlyPlayingAnswersSqliteModelArrayList.get(answerSelectId).getCorrect_answer() == 1) {
                            showSuccessLight(optionView, validRelativeLayout);
                        } else {
                            showFailureLight(optionView, invalidRelativeLayout, optionTextView);
                        }
                    }

                    @Override
                    public void onAnimationCancel(Animator animator) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animator) {

                    }
                })
                .playOn(optionView);
    }

    private void resetViewBackground() {

        validOneRelativeLayout.setVisibility(View.INVISIBLE);
        validTwoRelativeLayout.setVisibility(View.INVISIBLE);
        validThreeRelativeLayout.setVisibility(View.INVISIBLE);

        invalidOneRelativeLayout.setVisibility(View.INVISIBLE);
        invalidTwoRelativeLayout.setVisibility(View.INVISIBLE);
        invalidThreeRelativeLayout.setVisibility(View.INVISIBLE);

        optionOneView.setBackground(ContextCompat.getDrawable(QuizActivity.this, R.drawable.transparency_option_border));
        optionTwoView.setBackground(ContextCompat.getDrawable(QuizActivity.this, R.drawable.transparency_option_border));
        optionThreeView.setBackground(ContextCompat.getDrawable(QuizActivity.this, R.drawable.transparency_option_border));

    }

    private void scrollCountRcycler() {
        questionCountRecyclerView = findViewById(R.id.questionCountRecyclerView);
        prepareRecyclerCount();
//        DisplayMetrics displayMetrics = new DisplayMetrics();
//        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
//        int height = (int) (displayMetrics.heightPixels/displayMetrics.density);
//        questionCountRecyclerView.setPadding(0, 0, 0, height);
//        questionCountRecyclerView.setClipToPadding(false);
        mAdapter = new QuestionsCountAdapter(questionCountModelList, QuizActivity.this, currentlyPlayingMainSqliteModel.size());
        questionCountRecyclerView.setHasFixedSize(true);
        questionCountRecyclerView.setLayoutManager(new MyCustomLayoutManager(getApplicationContext()));
        questionCountRecyclerView.setItemAnimator(new DefaultItemAnimator());
        questionCountRecyclerView.setAdapter(mAdapter);
//        SnapHelper snapHelper = new LinearSnapHelper();
//        snapHelper.attachToRecyclerView(questionCountRecyclerView);

        counterTextView = findViewById(R.id.counterTextView);
        counterTextView.setOnClickListener(view -> {
            startActivity(new Intent(QuizActivity.this, YouLoseActivity.class));
            finish();
        });
    }

    private void prepareRecyclerCount() {
        for (int i = 1; i < currentlyPlayingMainSqliteModel.size()+1; i++) {
            QuestionCountModel questionCountModel = new QuestionCountModel();
            questionCountModel.setQuesCount(String.valueOf(i));
            if (i == 1)
                questionCountModel.setHighlight(1);
            else
                questionCountModel.setHighlight(-1);
            questionCountModelList.add(questionCountModel);
        }

//        mAdapter.notifyDataSetChanged();
    }

    private void startCountdown() {
        isCountDownFinish = false;
        count = new CountDownTimer(31000, 1000) {
            public void onTick(long millisUntilFinished) {
                counterTextView.setText(((millisUntilFinished / 1000) - 1) + " sec");
            }

            public void onFinish() {

                Handler refresh = new Handler(Looper.getMainLooper());
                refresh.post(new Runnable() {
                    public void run() {
                        try {
                            totalScore = totalScore - 5;
                            fullyScored = 0;
                            passed_result = "none";
                            isClickEnabled = true;
                            validateResult();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
                if (count != null) {
                    count.cancel();
                }
            }
        };

        count.start();
    }

    private void validateResult() {
        updateResultInDb();

        if (positionCount + 1 == currentlyPlayingMainSqliteModel.size()) {
            ScoresSqliteModel scoresSqliteModels = scoresTableQueries.getScoresMain();
            List<CheckedResultsSqliteModel> checkedResultsSqliteModelList = checkedResultsTableQueries.getAllAnswerResults();

            submitResults(jsonForSubmitResult(scoresSqliteModels, checkedResultsSqliteModelList));

        } else {
            Handler refresh = new Handler(Looper.getMainLooper());
            refresh.post(new Runnable() {
                public void run() {
                    try {
                        isClickEnabled = true;
                        resetViews();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            if (count != null) {
                count.cancel();
            }
        }
    }

    private void showSuccessLight(View optionView, RelativeLayout validReltiveLayout) {
        optionView.setBackground(ContextCompat.getDrawable(QuizActivity.this, R.drawable.valid_answer_border));
        validReltiveLayout.setVisibility(View.VISIBLE);
        YoYo.with(Techniques.ZoomIn)
                .duration(1000)
                .withListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animator) {

                    }

                    @Override
                    public void onAnimationEnd(Animator animator) {

                        totalScore = totalScore + 10;
                        passed_result = "true";

                        validateResult();
                    }

                    @Override
                    public void onAnimationCancel(Animator animator) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animator) {

                    }
                })
                .playOn(validReltiveLayout);
    }

    private void showFailureLight(View optionView, RelativeLayout invalidRelativeLayout, TextView optionTextView) {
        optionView.setBackground(ContextCompat.getDrawable(QuizActivity.this, R.drawable.invalid_answer_border));
        invalidRelativeLayout.setVisibility(View.VISIBLE);
        YoYo.with(Techniques.ZoomIn)
                .duration(1000)
                .withListener(new Animator.AnimatorListener() {
                    @Override
                    public void onAnimationStart(Animator animator) {

                    }

                    @Override
                    public void onAnimationEnd(Animator animator) {
                        fullyScored = 0;
                        totalScore = totalScore - 5;
                        showDialogForInvalidAnswer(currentlyPlayingMainSqliteModel.get(positionCount).getExplanation());
                    }

                    @Override
                    public void onAnimationCancel(Animator animator) {

                    }

                    @Override
                    public void onAnimationRepeat(Animator animator) {

                    }
                })
                .playOn(invalidRelativeLayout);
    }

    private void updateResultInDb() {

        final CheckedResultsSqliteModel checkedResultsSqliteModel = new CheckedResultsSqliteModel();
        checkedResultsSqliteModel.setQuestion_id(currentlyPlayingAnswersSqliteModelArrayList.get(answerSelectId).getQuestion_id());
        if (!passed_result.equals("none")) {
            checkedResultsSqliteModel.setClicked_id(currentlyPlayingAnswersSqliteModelArrayList.get(answerSelectId).getAnswer_id());
        } else {
            checkedResultsSqliteModel.setClicked_id(-1);
        }
        checkedResultsSqliteModel.setPassed_result(passed_result);

        checkedResultsTableQueries.insertCheckedResults(checkedResultsSqliteModel);

        scoresTableQueries.deleteAllScores();
        final ScoresSqliteModel scoresSqliteModel = new ScoresSqliteModel();
        scoresSqliteModel.setCategory_name(currentlyPlayingMainSqliteModel.get(0).getCategory());
        scoresSqliteModel.setCategory_id(currentlyPlayingMainSqliteModel.get(0).getCategory_id());
        scoresSqliteModel.setStep_id(currentlyPlayingMainSqliteModel.get(0).getSteps());
        if (currentlyPlayingMainSqliteModel.get(0).getLevel().equals("Begginer")) {
            scoresSqliteModel.setLevel_id(1);
        } else if (currentlyPlayingMainSqliteModel.get(0).getLevel().equals("Intermediate")) {
            scoresSqliteModel.setLevel_id(2);
        } else {
            scoresSqliteModel.setLevel_id(3);
        }
        scoresSqliteModel.setTotal_mark(250);
        scoresSqliteModel.setScored_mark(totalScore);
        scoresSqliteModel.setFull_scored(fullyScored);

        scoresTableQueries.insertScores(scoresSqliteModel);

    }

    private void submitResults(SubmitResultModel submitResultModel) {
        final CustomProgress progressDialog = new CustomProgress(this);
        progressDialog.show();

        SmartSurveyApplication smartSurveyApplication = SmartSurveyApplication.get(this);
        RetrofitService retrofitService = smartSurveyApplication.getRetrofitService();

        Call<SubmitResultsModel> categoriesCall = retrofitService.submitResults(appPreferences.getData(AppConfiguration.MY_TOKEN), submitResultModel);
        categoriesCall.enqueue(new Callback<SubmitResultsModel>() {
            @Override
            public void onResponse(Call<SubmitResultsModel> call, Response<SubmitResultsModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    if (response.body().getStatus() == 6000) {
                        for (SubmitResultsModel.DataBean.PlayedBean dataBean : response.body().getData().getPlayed()) {
                            //complete status checking
                            if (dataBean.getStep_complete() == 0) {
                                stepIdToPlay = dataBean.getStep_id();
                                break;
                            }
                        }

                        UserDataTableQueries userDataTableQueries = UserDataTableQueries.sharedInstance(getApplicationContext());
                        userDataTableQueries.deleteAllUserDetails();

                        SubmitResultsModel loginModel = new SubmitResultsModel();
                        loginModel.setData(response.body().getData());

                        userDataTableQueries.insertUserDetailsOnQuizComplete(loginModel);

                        userDataTableQueries.updateMark(response.body().getData());

                        if (totalScore > 30) {
                            Intent quiz_start_intent = new Intent(QuizActivity.this, YouWinActivity.class);
                            quiz_start_intent.putExtra("selectedCategoryId", response.body().getData().getCategory_id());
                            quiz_start_intent.putExtra("currentLevelId", response.body().getData().getStep_id());
                            quiz_start_intent.putExtra("stepIdToPlay", stepIdToPlay);
                            quiz_start_intent.putExtra("totalMark", response.body().getData().getUser_mark());
                            quiz_start_intent.putExtra("playerType", response.body().getData().getLevel_id());
                            startActivity(quiz_start_intent);
                        } else {
                            Intent quiz_start_intent = new Intent(QuizActivity.this, YouLoseActivity.class);
                            quiz_start_intent.putExtra("selectedCategoryId", response.body().getData().getCategory_id());
                            quiz_start_intent.putExtra("currentLevelId", response.body().getData().getStep_id());
                            quiz_start_intent.putExtra("stepIdToPlay", stepIdToPlay);
                            quiz_start_intent.putExtra("totalMark", response.body().getData().getUser_mark());
                            quiz_start_intent.putExtra("playerType", response.body().getData().getLevel_id());
                            startActivity(quiz_start_intent);
                        }
                        finish();
                    } else if (response.body().getStatus() == 6004) {
                        AlertDialogCustom.sessionExpiredDialog(QuizActivity.this);
                    } else {
                        AlertDialogCustom.commonAlertDialog(QuizActivity.this, response.body().getMessage());
                    }
                } else {
                    AlertDialogCustom.commonAlertDialog(QuizActivity.this, String.valueOf(response.code()));
                }

            }

            @Override
            public void onFailure(Call<SubmitResultsModel> call, Throwable t) {
                System.out.println("t = " + t.getMessage());
                progressDialog.dismiss();
                AlertDialogCustom.commonAlertDialog(QuizActivity.this, getString(R.string.went_wrong_wait));
            }

        });
    }

    public SubmitResultModel jsonForSubmitResult(ScoresSqliteModel scoresSqliteModels, List<CheckedResultsSqliteModel> checkedResultsSqliteModelList) {

        try {
            SubmitResultModel submitResultModel = new SubmitResultModel();
            submitResultModel.setCategory_id(scoresSqliteModels.getCategory_id());
            submitResultModel.setFull_scored(scoresSqliteModels.getFull_scored());
            submitResultModel.setLevel_id(scoresSqliteModels.getLevel_id());
            submitResultModel.setScored_mark(scoresSqliteModels.getScored_mark());
            submitResultModel.setStep_id(scoresSqliteModels.getStep_id());
            submitResultModel.setUser_id(appPreferences.getData(AppConfiguration.USER_ID));
            if (fullyScored == 1) {
                submitResultModel.setTotal_mark(scoresSqliteModels.getTotal_mark() + 10);
            } else
                submitResultModel.setTotal_mark(scoresSqliteModels.getTotal_mark());
            submitResultModel.setResult(checkedResultsSqliteModelList);

            System.out.println("response.body() " + new Gson().toJson(submitResultModel).toString());

            return submitResultModel;

        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }

    }

    //language wrapper
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }

    @Override
    public void onBackPressed() {
    }
}