package com.kawika.smart_survey.views;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.kawika.smart_survey.R;
import com.kawika.smart_survey.alerts.AlertDialogCustom;
import com.kawika.smart_survey.api_services.RetrofitService;
import com.kawika.smart_survey.application.SmartSurveyApplication;
import com.kawika.smart_survey.config.AppConfiguration;
import com.kawika.smart_survey.database.UserDataTableQueries;
import com.kawika.smart_survey.models.AuthenticationModel;
import com.kawika.smart_survey.models.CategoriesSqliteModel;
import com.kawika.smart_survey.preferences.AppPreferences;
import com.kawika.smart_survey.utils.CustomProgress;
import com.kawika.smart_survey.utils.LocaleManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.kawika.smart_survey.alerts.AlertDialogCustom.alertDialog;
import static com.kawika.smart_survey.config.AppConfiguration.PERMISSIONS_REQUEST_READ_PHONE;
import static com.kawika.smart_survey.config.AppConfiguration.READ_PHONE_ALERT;
import static com.kawika.smart_survey.database.CategoriesTableQueries.categoriesTableQueries;
import static com.kawika.smart_survey.database.TopPlayersTableQueries.topPlayersTableQueries;


public class LoginActivity extends BaseAppCompatActivity {

    EditText emailEditText, passwordEditText;
    private static final String TAG = "LoginActivity";
    private CardView emailButtonCardView, confirmButtonCardView;
    private Button loginButton;
    CardView passwordButtonCardView;
    TextView forgetPass;
    private ImageView profileImageView;
    private TextView welcomeTextView;
    private YoYo.YoYoString rope;
    private AppPreferences appPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        emailButtonCardView = findViewById(R.id.emailButtonCardView);
        passwordButtonCardView = findViewById(R.id.passwordButtonCardView);
        confirmButtonCardView = findViewById(R.id.confirmButtonCardView);
        loginButton = findViewById(R.id.loginButton);
        forgetPass = findViewById(R.id.forgetPass);
        profileImageView = findViewById(R.id.profileImageView);
        welcomeTextView = findViewById(R.id.welcomeTextView);

        profileImageView.setVisibility(View.INVISIBLE);
        welcomeTextView.setVisibility(View.INVISIBLE);
        emailButtonCardView.setVisibility(View.INVISIBLE);
        passwordButtonCardView.setVisibility(View.INVISIBLE);
        confirmButtonCardView.setVisibility(View.INVISIBLE);

        loginButton.setOnClickListener(view -> {
            //validation
            if (validate()) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (ContextCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(LoginActivity.this, new String[]{Manifest.permission.READ_PHONE_STATE}, PERMISSIONS_REQUEST_READ_PHONE);
                        } else {
                            loginServerCall();
                        }
                    } else {
                        loginServerCall();
                    }
                } catch (Exception e) {
                    Log.e("Welcome activity", "PermissionM: ", e);
                }
            }
        });

        forgetPass.setOnClickListener(v -> {
            Intent i = new Intent(LoginActivity.this, ForgetPasswordActivity.class);
//                i.putExtra(EXTRA_TYPE, TYPE_PROGRAMMATICALLY);
            transitionTo(i);
            if (rope != null) {
                rope.stop(true);
            }
        });

        LinearLayout registerRelativeLayout = findViewById(R.id.registerRelativeLayout);
        registerRelativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
                if (rope != null) {
                    rope.stop(true);
                }

            }
        });
//
//        backArrowImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                finish();
//            }
//        });
        playAnim();

        appPreferences = AppPreferences.getInstance(LoginActivity.this, AppConfiguration.SMART_SURVEY_PREFS);

    }

    private void playAnim() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                profileImageView.setVisibility(View.VISIBLE);
                rope = YoYo.with(Techniques.ZoomIn)
                        .duration(500)
                        .playOn(profileImageView);
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        welcomeTextView.setVisibility(View.VISIBLE);
                        rope = YoYo.with(Techniques.FadeIn)
                                .duration(700)
                                .playOn(welcomeTextView);
                        Handler handler = new Handler();
                        handler.postDelayed(() -> {
                            emailButtonCardView.setVisibility(View.VISIBLE);
                            rope = YoYo.with(Techniques.BounceIn)
                                    .duration(400)
                                    .playOn(emailButtonCardView);
                            Handler handler12 = new Handler();
                            handler12.postDelayed(() -> {
                                passwordButtonCardView.setVisibility(View.VISIBLE);
                                rope = YoYo.with(Techniques.BounceIn)
                                        .duration(400)
                                        .playOn(passwordButtonCardView);
                                Handler handler1 = new Handler();
                                handler1.postDelayed(() -> {
                                    confirmButtonCardView.setVisibility(View.VISIBLE);
                                    rope = YoYo.with(Techniques.BounceIn)
                                            .duration(400)
                                            .playOn(confirmButtonCardView);
                                }, 100);
                            }, 100);
                        }, 200);
                    }
                }, 100);
            }
        }, 50);
    }

    /**
     * server communication of login
     */
    public void loginServerCall() {
        //progress dialog custom method
        CustomProgress progressDialog = new CustomProgress(LoginActivity.this);
        progressDialog.show();

        // Web service contact
        // #library : Retrofit
        SmartSurveyApplication smartSurveyApplication = SmartSurveyApplication.get(this);
        RetrofitService retrofitService = smartSurveyApplication.getRetrofitService();
        //call object
        Call<AuthenticationModel> loginCall = retrofitService.loginUser(emailEditText.getText().toString(),
                passwordEditText.getText().toString(), getImei());
        //method
        loginCall.enqueue(new Callback<AuthenticationModel>() {
            @Override
            public void onResponse(Call<AuthenticationModel> call, Response<AuthenticationModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    if (response.body().getStatus() == 6000) {
                        onLoginSuccess(response.body().getData());
                    } else {
                        AlertDialogCustom.commonAlertDialog(LoginActivity.this, response.body().getMessage());
                    }
                }else{
                    AlertDialogCustom.commonAlertDialog(LoginActivity.this, getString(R.string.went_wrong_wait));

                }
            }

            @Override
            public void onFailure(Call<AuthenticationModel> call, Throwable t) {
                //progress bar dismiss
                progressDialog.dismiss();
                AlertDialogCustom.commonAlertDialog(LoginActivity.this, getString(R.string.went_wrong_wait));
            }

        });
    }

    /**
     * success message of login
     * @param data
     */
    public void onLoginSuccess(AuthenticationModel.DataBean data) {
        UserDataTableQueries userDataTableQueries = UserDataTableQueries.sharedInstance(getApplicationContext());
        userDataTableQueries.deleteAllUserDetails();

        AuthenticationModel loginModel = new AuthenticationModel();
        loginModel.setData(data);

        userDataTableQueries.insertUserDetails(loginModel);

        categoriesTableQueries = categoriesTableQueries.sharedInstance(LoginActivity.this);
        topPlayersTableQueries = topPlayersTableQueries.sharedInstance(LoginActivity.this);
        categoriesTableQueries.deleteAllCategories();
        topPlayersTableQueries.deleteAllTopPlayers();

        for (int i = 0; i < data.getUser_categories().size(); i++) {
            final CategoriesSqliteModel categoriesSqliteModel = new CategoriesSqliteModel();
            categoriesSqliteModel.setEn_category_id(data.getUser_categories().get(i).getEn_category_id());
            categoriesSqliteModel.setCategory_color(data.getUser_categories().get(i).getCategory_color());
            categoriesSqliteModel.setCategory_name(data.getUser_categories().get(i).getCategory_name());
            categoriesSqliteModel.setCrown(data.getUser_categories().get(i).getCrown());
            categoriesSqliteModel.setCrown_image(data.getUser_categories().get(i).getCrown_image());
            categoriesSqliteModel.setLevel_count(data.getUser_categories().get(i).getLevel_count());
            categoriesSqliteModel.setIs_followed(data.getUser_categories().get(i).getIs_followed());
            categoriesSqliteModel.setImage_path(data.getUser_categories().get(i).getImage_path());

            if (!categoriesTableQueries.insertAllTopics(categoriesSqliteModel))
                Toast.makeText(LoginActivity.this, "Something went wrong. Please restart .", Toast.LENGTH_LONG).show();

            if (data.getUser_categories().get(i).getTop_players().size() > 0) {
                for (int j = 0; j < data.getUser_categories().get(i).getTop_players().size(); j++) {
                    int categorId = data.getUser_categories().get(i).getEn_category_id();
                    String firstName = data.getUser_categories().get(i).getTop_players().get(j).getFirstname();
                    String lastName = data.getUser_categories().get(i).getTop_players().get(j).getLastname();
                    int userId = data.getUser_categories().get(i).getTop_players().get(j).getUser_id();
                    int totalMark = data.getUser_categories().get(i).getTop_players().get(j).getTotal_mark();
                    int rank;
                    if (j == 0)
                        rank = 1;
                    else
                        rank = 2;
                    String imagePath = "http://e-learning.kawikatech.com/data/profile/" + data.getUser_categories().get(i).getTop_players().get(j).getImage();
                    String categoryName = data.getUser_categories().get(i).getTop_players().get(j).getCategory_name();
                    topPlayersTableQueries.insertTopPlayers(categorId, firstName, lastName, userId, totalMark, rank, imagePath, categoryName);
                }
            }

            }

        appPreferences.saveData(AppConfiguration.MY_TOKEN, data.getDevice_id());
        appPreferences.saveData(AppConfiguration.USER_ID, String.valueOf(data.getId()));
        appPreferences.saveBoolean(AppConfiguration.IS_LOGGED, true);

        startActivity(new Intent(LoginActivity.this, HomeActivity.class));
        Toast.makeText(getBaseContext(), R.string.login_success, Toast.LENGTH_LONG).show();
        finish();

    }


    public boolean validate() {
        boolean valid = true;

        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

            //emailEditText.setError("enter a valid email address");
            rope = YoYo.with(Techniques.Shake)
                    .duration(700)
                    .playOn(emailButtonCardView);
            valid = false;
            Toast.makeText(getBaseContext(), "Enter a valid email address", Toast.LENGTH_SHORT).show();
        }
        if (password.isEmpty() || password.length() < 3) {
            //  passwordEditText.setError("between 4 and 10 alphanumeric characters");
            rope = YoYo.with(Techniques.Shake)
                    .duration(700)
                    .playOn(passwordButtonCardView);
            valid = false;
            Toast.makeText(getBaseContext(), "Enter a valid password", Toast.LENGTH_SHORT).show();
        }

        return valid;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_REQUEST_READ_PHONE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loginServerCall();
            } else {
                if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_PHONE_STATE)) {
                    AlertDialogCustom.permissionDialog(LoginActivity.this, "Turn on READ PHONE Permission from SETTINGS --> PERMISSIONS");
                } else {
                    alertDialog(LoginActivity.this, "You must accept PHONE permission to continue", READ_PHONE_ALERT);

                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private String getImei(){
        TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getDeviceId();
    }


    //language wrapper
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(LocaleManager.setLocale(base));
    }
}
