package com.kawika.smart_survey.callbacks;
/*
 * Created by akhil on 21/02/18.
 */

public interface RecyclerClickAvatar {
    void onRowClick(int position, String data);
}
