package com.kawika.smart_survey.callbacks;
/*
 * Created by akhil on 09/03/18.
 */

public interface LifeCycleDelegate {
    void onAppBackgrounded();

    void onAppForegrounded();
}
